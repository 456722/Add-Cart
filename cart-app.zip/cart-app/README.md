# React + Vite

     
 


import React, { useState } from 'react';
import Productitem from './Productitem';
import "./Detail.css";
import Carttext from './Carttext';

const Details = () => {
  const [cart, setCart] = useState([]);
  const products = [
    { id: 1, name: 'laptop', price: 678 },
    { id: 2, name: 'mobile', price: 300 },
    { id: 3, name: 'microwave', price: 550 },
  ];

   const addtocart=(product)=>{
     setCart([...cart,{...product}])
   }

   const removecart = ()=>{

   }

  return (
    <>
      <header className='app_header'>
        <h1>Shopping Cart</h1>
        <div className="cart_icon">🛒</div>
      </header>
      <div className="product_list">
        <h2>Products</h2>
        <ul>
          {products.map(product => (
            <Productitem key={product.id} product={product}  addtocart =  {addtocart}/>
          ))}
        </ul>
      </div>

      <div className="cart">
        <h2>Your Cart</h2>
        <ul>
        
        {cart.map(item => (
            <Carttext key={item.id} item={item}  removecart = {removecart}/>
          ))}

        </ul>
      </div>
    </>
  );
};

export default Details;


    

       

import React from 'react';

const Productitem = ({ product }) => {
  return (
    <ul>
    <li>
      {product.name}
      <p>Price: ${product.price}</p>
      <button onClick={()=>product.addtocart(product.product)}>Add to cart</button>
    </li>

    </ul>
  );
};

export default Productitem;


  

  import React from 'react'
  
  const Carttext = (props) => {
    return (
     <>
     {props.item.name}
     </>
    )
  }
  
  export default Carttext  


           

 

 