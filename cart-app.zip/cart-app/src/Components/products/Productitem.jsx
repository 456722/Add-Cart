

import React from 'react';

const Productitem = ({ product, addtocart }) => {
  return (
    <ul>
      <li>
        {product.name}
        <p>Price: ${product.price}</p>
        <button onClick={() => addtocart(product)}>Add to cart</button>
      </li>
    </ul>
  );
};

export default Productitem;
