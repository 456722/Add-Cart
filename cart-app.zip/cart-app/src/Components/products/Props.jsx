

  import React from 'react'
  
  const Props = (props) => {
    return (
    <>
    <h1>props in react js</h1>
    <li>
     {props.name}
     </li>
     {props.title}
    
    </>
    )
  }

  props.defaultProps={
  title:'samir'
  }
  
  export default Props