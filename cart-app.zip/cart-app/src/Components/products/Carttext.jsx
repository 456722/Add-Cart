

  import React from 'react'
  
  const Carttext = (props) => {
    return (
     <>
     <ul>
      <li>
        {props.item.name}
        <p>Price: ${props.item.price}</p>
       
      </li>
    </ul>
     </>
    )
  }
  
  export default Carttext