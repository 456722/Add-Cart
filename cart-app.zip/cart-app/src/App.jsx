

import React from "react";
import Deatails from "./Components/products/Deatails";
import Productitem from "./Components/products/Productitem";




 

const App = () => {
  
  return (
   <> 
  
 <Deatails/>

   </>
  );
}

export default App;
